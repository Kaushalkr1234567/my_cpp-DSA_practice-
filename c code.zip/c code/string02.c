#include <stdio.h>
#include <string.h>

int main()
{
    char s1[] = "Kuashal";
    char s2[] = "Manoj";
    // char s3[34];

    printf("The strcmp for s1, s2 returned %d", strcmp(s1, s2));

    //    puts(strcat(s1 ,s2));
    // printf("The length of s1 is %d\n", strlen(s1));
    // printf("The length of s2 is %d\n", strlen(s2));

    // printf("The reversed string of s1 is:- ");
    // puts(strrev(s1));
    //  printf("s1 and s2 is copy into s3 is ");

    // strcpy(s3, strcat(s1 , s2));
    // puts(s3);

    return 0;
}