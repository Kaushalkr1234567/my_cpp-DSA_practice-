#include <stdio.h>

void printStr(char str[])
{
    int i = 0;
    while (str[i] != '\0')

    {
        printf("%c", str[i]);
        i++;
    }
}
int main()
{
    // char str[] = {'k', 'a', 'u', 's', 'h', 'a', 'l','\0'};
    // OR//
    // char str[]= "KAUSHAL KUMAR";
    char str[34];
    gets(str);

    // printStr(str);
    // OR//
    printf("Using printf: \n %s\n", str);
    printf("Using puts: \n");
    puts(str);

    return 0;
}