#include<stdio.h>

int main(){
    int a=50,b=69,c=40;
    printf("%d",a+b+c);
    return 0;
}