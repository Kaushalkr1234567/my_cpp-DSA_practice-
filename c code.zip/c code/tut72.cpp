#include <iostream>
#include <list>

using namespace std;

int main()
{

    list<int> list1; // empty list of 0 length(size not define)

    list1.push_back(5);
    list1.push_back(7);
    list1.push_back(1);
    list1.push_back(9);
    list1.push_back(12);
    list<int> :: iterator iter;
    iter = list1.begin();
    cout<< *iter<<" ";
    iter++;
    cout<< *iter<<" ";
    iter++;
    cout<< *iter<<" ";
    iter++;
    cout<< *iter<<" ";
    //OR we can create a function to print these value -->>tut72b.cpp

    return 0;
}
