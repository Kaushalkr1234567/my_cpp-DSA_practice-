#include <stdio.h>

// using namespace std;

int main()
{
    printf("Table of 3 is:");

    int i = 3;

    do
    {

        printf("%d\n", i);
        i =i + 3;
    } while (i <= 30);
    return 0;
}