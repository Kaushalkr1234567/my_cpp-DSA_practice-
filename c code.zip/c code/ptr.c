#include<stdio.h>

int main(){
    int a=76;
    int*ptra= &a;
    printf(" The value of a is %d\n", *ptra);
    printf(" The value of a is %d\n", a);
    printf(" The address of a is %p\n", &a);
    printf(" The address of a is %x.\n", &a);
    return 0;
}