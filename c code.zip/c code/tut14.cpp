#include <iostream>
using namespace std;

// struct employee
// {
//     /* data */
//     int eId; //4
//     char favChar; //1
//     float salary; //4
// };
// OR
// typedef struct employee
// {
//   /* data */
//   int eId;      // 4                //Means insted of struct employee we can also simply used ep
//   char favChar; // 1
//   float salary; // 4
// } ep;

union money
{
  /* data */
  int rice;     // 4
  char car;     // 1
  float pounds; // 4
};

int main()
{
  // enum Meal{ breakfast, lunch, dinner};
  // Meal m1 = lunch;
  // cout<<(m1==2);
  // cout<<breakfast;
  // cout<<lunch;
  // cout<<dinner;
  union money m1;
  m1.rice = 34;
  // m1.car = 'c';
  cout << m1.rice<<endl;
  cout << m1.car;

  // ep kaushal;
  // struct employee kaushal;
  // struct employee shubham;
  // struct employee rohanDas;
  // kaushal.eId = 1;
  // kaushal.favChar = 'A';
  // kaushal.salary = 12000;
  // cout << "Kaushal's Id is " << kaushal.eId << endl;
  // cout << "Kaushal's fav char. is " << kaushal.favChar << endl;
  // cout << "Kaushal's Salery is Rs." << kaushal.salary << endl;
  return 0;
}
