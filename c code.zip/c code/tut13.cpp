#include <iostream>
using namespace std;

int main()
{
    // Array Example
    int Englishmarks[] = {23, 45, 56, 89};

    // int mathMarks[4];
    // mathMarks[0] = 2278;
    // mathMarks[1] = 738;
    // mathMarks[2] = 378;
    // mathMarks[3] = 578;

    // cout << "These are maths marks " << endl;
    // cout << "The Mathsmarks of Roll No.0 is " << mathMarks[0] << endl;
    // cout << "The Mathsmarks of Roll No.1 is " << mathMarks[1] << endl;
    // cout << "The Mathsmarks of Roll No.2 is " << mathMarks[2] << endl;
    // cout << "The Mathsmarks of Roll No.3 is " << mathMarks[3] << endl;

    // You can change the value of an array
    // Englishmarks[2] = 455;
    // cout << "These are Englishmarks" << endl;

    // print using the for loop
    // for (int i = 0; i <= 3; i++)
    // {
    //     cout << "The Englishmarks of Roll No. " << i << " is " << Englishmarks[i] << endl;
    // }

    // Quick quiz: do the same using while and do-while loops?
    // cout << "Print using the while loop " << endl;
    //     int i=0;
    //  while (i<=3)
    //  {
    //     cout << "The Englishmarks of Roll No. " << i << " is " << Englishmarks[i] << endl;
    //     i=i+1;
    //  }

    // Pointers and arrays
    int *p = Englishmarks;
    // cout << *(p++) << endl;
    // cout << *(+p) << endl;
    // cout << *(++p) << endl;
    // cout << *(p) << endl;
    cout << "The value of *p is " << *p << endl;
    cout << "The value of *(p+1) is " << *(p + 1) << endl;
    cout << "The value of *(p+2) is " << *(p + 2) << endl;
    cout << "The value of *(p+3) is " << *(p + 3) << endl;

    return 0;
}