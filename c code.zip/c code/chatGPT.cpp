#include <iostream>
#include <vector>

using namespace std;

int main() {
  // Create two matrices.
  vector<vector<int>> A = {{1, 2, 3}, {4, 5, 6}};
  vector<vector<int>> B = {{7, 8, 9}, {10, 11, 12}};

  // Multiply the matrices.
  vector<vector<int>> C = matmul(A, B);

  // Print the result.
  for (int i = 0; i < C.size(); i++) {
    for (int j = 0; j < C[i].size(); j++) {
      cout << C[i][j] << " ";
    }
    cout << endl;
  }

  return 0;
}