#include<stdio.h>

int main(){
    int a,b;
    printf("Enter the value of a \n");
    
    printf("Enter the value of b \n");

    printf("The Sum of a and b is %d",a + b);
    return 0;
}