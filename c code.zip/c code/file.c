#include <stdio.h>

int main()
{
    FILE *ptr = NULL;
    char string[64] = "AVENGER ENDGAME";

          //******Reading a file***
    // ptr = fopen("kaushal.txt", "r");
    // fscanf(ptr, "%s", string);
    // printf("The content of this file has %s\n", string);


         // //******Writing a file***
    // ptr = fopen("kaushal.txt", "w");
    // fprintf(ptr, "%s", string);


        //***Adding a content***
    ptr = fopen("kaushal.txt", " a");
    fprintf(ptr, "%s", string);

    return 0;
}