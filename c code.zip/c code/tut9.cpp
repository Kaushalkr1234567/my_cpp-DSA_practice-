#include <iostream>

using namespace std;

int main()
{

    // int age;
    // cout << "Tell me your age" << endl;
    // cin >> age;

    // 1. Selection control structure: If else-if else ladder
    // if((age<18) && (age>0)){
    //     cout<<"You can not come to my party"<<endl;
    // }
    // else if(age==18){
    //     cout<<"You are a kid and you will get a kid pass to the party"<<endl;
    // }
    // else if(age<1){
    //     cout<<"You are not yet born"<<endl;
    // }
    // else{
    //     cout<<"You can come to the party"<<endl;
    // }

    // 2. Selection control structure: Switch Case statements
    int ticket;
    cout << "Tell me your ticket No." << endl;
    cin >> ticket;

    switch (ticket)
    {
    case 5:
        cout << "Your ticket No. is matched with 5 and You are Winner" << endl;
        break;
    case 14:
        cout << "Your ticket No. is matched with 14 and You are Winner" << endl;
        break;
    case 24:
        cout << "Your ticket No. is matched with 24 and You are Winner" << endl;
        break;

    default:
        cout << "You are not Winner b/c your ticket No. is not matched" << endl;
        break;
    }

    cout << "Done with switch case statement";
    return 0;
}
