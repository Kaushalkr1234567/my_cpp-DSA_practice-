#include <stdio.h>

int main()
{
    int i, j = 0;

    for (i=0; i < 5; )

    {
        printf("%d %d \n\n\n\n\n\n", j, i);
        i++;
        j++;
        
        
    }
    return 0;
}