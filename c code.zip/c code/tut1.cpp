#include <iostream>
using namespace std;
int main()
{

    int sum = 6;

    cout << "Hello World " << sum;
    return 0;
}
