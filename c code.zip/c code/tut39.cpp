#include<iostream>
using namespace std;

class Base{
    protected: //it means we can make this(int a) inheritance 
        int a; 
    private:
        int b;

};

class Derived: protected Base{
   
};

int main(){
    Base b;
    Derived d;
    cout<<b.a; //we already know it can't we accesss
    // cout<<d.a; // Will not work since a is protected in both base as well as derived class
    return 0;
}

