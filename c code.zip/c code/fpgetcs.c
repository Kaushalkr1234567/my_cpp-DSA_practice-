#include <stdio.h>

int main()
{
    FILE *ptr = NULL;
    ptr = fopen("kaushal.txt", "r");
    // char c = fgetc(ptr);
    // printf("The character I was read %c\n", c);
    // c = fgetc(ptr);
    // printf("The character I was read %c\n", c);

    // char str[3];
    // fgets(str, 15, ptr);
    // printf("The string is %s\n", str);

    fputc('O', ptr);
    fputs("This is Kaushal", ptr);

    fclose(ptr);

    return 0;
}